import { Component } from '@angular/core';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})

export class BooksComponent {
  storeName = 'Rockport';
  numBooks = 25;
  shelf1: Bookshelf;

  constructor() {
    this.shelf1 = new Bookshelf(new Book("joe", "hunger Games", [], []));
    this.addBooksToShelf();
  }

  addBooksToShelf() {
    this.shelf1.addBook(new Book("hank", "the maze runner", [], []));
    this.shelf1.addBook(new Book("sam", "the great gatsby", [], []));
  }
  
  newBook() {
    this.shelf1.addBook(new Book("ryan", "test book", [], []))
  }
}



class Book {
  author: string;
  title: string;
  borrows: Array<string>[];
  returns: Array<string>[];
  //cover

  constructor(author : string, title : string, borrows : Array<string>[], returns : Array<string>[]) {
      this.author = author; 
      this.title = title;
      this.borrows = borrows;
      this.returns = returns;
  }
}

class Bookshelf {
  contents : Array<Book>;

  constructor(first : Book) {
    this.contents = [];
    this.contents.push(first)
  }

  addBook(newBook : Book) : void {
      this.contents.push(newBook)
  }

}